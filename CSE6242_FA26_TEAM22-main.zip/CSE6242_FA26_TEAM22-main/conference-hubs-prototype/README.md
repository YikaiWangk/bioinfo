# Conference Hub Planner (prototype)

CSE 6242 project prototype. Where should NeurIPS / ICML / ICLR be held, and with how many hubs, so that
the authors who actually publish there emit the least flight CO₂ and face the fewest visa barriers?

Prior work picks hubs by hand (Klöwer et al., *Nature* 2020), reports one conference's footprint after
the fact, or optimizes CO₂ alone for small corporate meetings (ICAO Green Meetings Calculator). This
prototype optimizes multi-hub placement for real ML venues with a visa-aware cost, interactively.

## Run

Dependencies are managed with [pixi](https://pixi.sh); install it once, then:

```bash
pixi run build   # fetch pinned raw data (~550 MB, gitignored) and write web/data/*.json (committed)
pixi run serve   # install JS libs, copy them into web/vendor/, serve at http://localhost:8642
pixi run lint    # Ruff (Python, ruff.toml) + ESLint (web/*.js, eslint.config.mjs); lint-fix applies safe fixes
```

**Lint on commit.** `pixi run lint`, `build` or `serve` also installs the repo's git hook
(`.githooks/pre-commit`), which runs `pixi run lint` before every commit and blocks it on failure.
CI (`.github/workflows/lint.yml`) runs the same check on every push and pull request.

Add `?selftest` to the URL to log the optimizer vs. brute force for k = 1. `pixi run fetch` alone
just downloads/verifies the raw data. The data in `web/data/` is committed, so `pixi run serve` works
without fetching anything.

## Dependencies & reproducibility

| What | Pinned by | Notes |
|---|---|---|
| Python 3.12, Node.js 22, Ruff 0.16.9 | `pixi.toml` + `pixi.lock` | conda-forge; the pipeline uses only the Python standard library |
| d3 7.9.0, topojson-client 3.1.0, world-atlas 2.0.2, ESLint 10.11.0 | `package.json` + `package-lock.json` | `npm ci` inside the pixi env; vendored to `web/vendor/` (gitignored), so the page makes no CDN requests and works offline |
| Raw datasets | commit SHAs / Zenodo record in `pipeline/fetch_data.py` + SHA-256s in `data/sources.lock.json` | every fetch verifies cached files against the lock; a corrupted or changed file is re-downloaded or the run fails |

To update a dataset: bump its pin in `fetch_data.py`, run `pixi run python pipeline/fetch_data.py --relock`,
then `pixi run build`, and commit the new lock together with the rebuilt `web/data/`. To add a Python
package (e.g. OR-Tools for the exact solver): `pixi add ortools`. For a browser library:
`pixi run npm install --save-dev --save-exact <pkg>` and add its file to the `vendor` task in `pixi.toml`.

## Data

| Source | Used for |
|---|---|
| [Paper Copilot paperlists](https://github.com/papercopilot/paperlists) | accepted papers with per-author affiliation, email domain, country |
| [ROR registry dump](https://zenodo.org/communities/ror-data) | affiliation → coordinates (matched by email domain, then by name) |
| [OurAirports](https://ourairports.com/data/) + [OpenFlights routes](https://github.com/jpatokal/openflights) | candidate hubs: airports with ≥ 40 nonstop destinations (233) |
| [Passport Index dataset](https://github.com/ilyankou/passport-index-dataset) | visa requirement per passport → destination |

Authors are deduplicated per venue-year, geocoded (~90% via ROR, the rest to their country's busiest
cell), and aggregated to a 0.5° grid: 144k author-venue-years in 5.8k grid rows.

## Model (`web/solver.js`)

- **CO₂:** round trip, great-circle × 1.08, UK DESNZ 2023 per-passenger-km factors incl. radiative
  forcing (domestic / short-haul / long-haul). Rail factor under 300 km.
- **Visa:** 0 none · 1 eTA / e-visa / on arrival · 2 visa required · 3 no admission. Penalty is
  `λ × [0, 0.25, 1, 10]` tCO₂e-equivalent per attendee.
- **Assignment:** each origin attends its cheapest hub.
- **Optimizer:** weighted p-median. Greedy add, then Teitz–Bart vertex substitution, run in a Web Worker
  (< 0.5 s for k = 5). Matches exhaustive search at k = 1 (`?selftest`).
- **Trade-off chart:** optimal solutions across λ ∈ {0 … 5}. Click one to load it.

## Known limitations / next steps for the final project

- **Missing years.** Paper Copilot has no affiliations for ICLR 2019/2020/2025/2026 or ICML 2026, so those
  venue-years are skipped (`MIN_COVERAGE` in `build.py`). Fill them from OpenReview profiles or the
  OpenAlex snapshot by title match.
- **Nationality proxy.** Institution country stands in for passport nationality, which understates visa
  barriers for international students.
- **Big-company domains.** These geocode to the company's HQ (e.g. google.com → Mountain View).
- **Visa model.** It covers requirements only. Next: add refusal rates (US State Dept, Schengen statistics)
  and processing times.
- **Optimizer realism.** There are no hub capacity limits; NeurIPS 2025 Mexico City was capped near 500.
  A capacitated p-median is the next algorithmic step. Also missing: cost of living, venue size, and
  population forecasts.
- **Stale routes.** OpenFlights route data is from 2014.
