"""Serve web/ locally with caching disabled, so edits to app.js / solver.js show up on a normal reload."""
import functools
import http.server
import sys
from pathlib import Path

WEB = Path(__file__).resolve().parent / "web"


class NoCacheHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8642
    handler = functools.partial(NoCacheHandler, directory=WEB)
    print(f"Serving {WEB} at http://localhost:{port}")
    http.server.ThreadingHTTPServer(("", port), handler).serve_forever()
