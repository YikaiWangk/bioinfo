"""Download the raw public datasets into data/raw/, pinned to fixed versions.

Every source is pinned (git commit or Zenodo record) below, and each file's SHA-256 is recorded in
data/sources.lock.json the first time it is downloaded. Later runs verify cached files against the
lock and re-download or fail on a mismatch, so every teammate builds from byte-identical inputs.

To move to newer data: bump a pin below, run with --relock, rebuild, and commit the new lock.

Sources
- Paper Copilot paperlists: every accepted paper at NeurIPS/ICML/ICLR with
  per-author affiliation, email domain and country (github.com/papercopilot/paperlists)
- ROR registry dump: ~120k research organizations with domains and coordinates (zenodo.org)
- OurAirports: worldwide airports, used as candidate hub cities
- OpenFlights routes: route counts per airport, used to keep only well-connected hubs
- Passport Index dataset: visa requirement for every passport -> destination pair
"""
import argparse
import hashlib
import json
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
LOCK = ROOT / "data" / "sources.lock.json"

# ---- pins ---------------------------------------------------------------------------------
PAPERLISTS_COMMIT = "9fcfd1234879a8e5630b5116dde411ec143dd763"  # 2026-07-01
OURAIRPORTS_COMMIT = "b62683270f29e5af471df9e5547b791b471f4ff9"  # 2026-10-01
OPENFLIGHTS_COMMIT = "7d1a611e070295dba776d6afb86e57d0d1aa1cef"  # 2026-09-21 (route data itself is from 2014)
PASSPORT_COMMIT = "e111423a6e7d39823dccfabf0c1801a725b82f6b"     # 2026-02-18
ROR_RECORD, ROR_FILE = "22902037", "v2.13-2026-09-22-ror-data.zip"

VENUES = ["nips", "icml", "iclr"]
YEARS = range(2019, 2027)

GITHUB_RAW = "https://raw.githubusercontent.com/{repo}/{sha}/{path}"


def sources():
    """(path under data/raw, URL) for every file the pipeline needs."""
    def github(repo, sha, path):
        return GITHUB_RAW.format(repo=repo, sha=sha, path=path)

    out = [(f"papers/{v}{y}.json", github("papercopilot/paperlists", PAPERLISTS_COMMIT, f"{v}/{v}{y}.json"))
           for v in VENUES for y in YEARS]
    out += [
        ("airports.csv", github("davidmegginson/ourairports-data", OURAIRPORTS_COMMIT, "airports.csv")),
        ("routes.dat", github("jpatokal/openflights", OPENFLIGHTS_COMMIT, "data/routes.dat")),
        ("passport-index-tidy-iso2.csv",
         github("ilyankou/passport-index-dataset", PASSPORT_COMMIT, "passport-index-tidy-iso2.csv")),
        ("ror-data.zip", f"https://zenodo.org/api/records/{ROR_RECORD}/files/{ROR_FILE}/content"),
    ]
    return out


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(1 << 20):
            h.update(chunk)
    return h.hexdigest()


def fetch(url, tmp):
    with urllib.request.urlopen(url, timeout=300) as r, open(tmp, "wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)


def download(url, dest):
    """Download url to dest. Returns False if the file doesn't exist at that version (HTTP 404)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    try:
        fetch(url, tmp)
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return False
        raise
    # Some yearly paper lists are stored in Git LFS: raw.githubusercontent.com returns a pointer for
    # those, and media.githubusercontent.com serves the actual object.
    with open(tmp, "rb") as f:
        is_lfs_pointer = f.read(40).startswith(b"version https://git-lfs")
    if is_lfs_pointer:
        fetch(url.replace("https://raw.githubusercontent.com/", "https://media.githubusercontent.com/media/"), tmp)
    tmp.replace(dest)
    return True


def main():
    ap = argparse.ArgumentParser(description="Download pinned raw data and verify it against the lock file.")
    ap.add_argument("--relock", action="store_true",
                    help="accept the pinned files as they are now and rewrite their hashes")
    args = ap.parse_args()

    lock = json.loads(LOCK.read_text()) if LOCK.exists() else {}
    new_lock, problems = {}, []
    for rel, url in sources():
        dest, entry = RAW / rel, lock.get(rel)
        pin_changed = entry is not None and entry["url"] != url
        if pin_changed and not args.relock:
            problems.append(f"{rel}: pin changed since the lock was written (run with --relock)")
            continue
        if args.relock:
            # Trust a cached file only if it came from the same pinned URL; otherwise fetch the new version.
            if pin_changed and dest.exists():
                dest.unlink()
            entry = None
        if entry and entry.get("missing"):
            new_lock[rel] = entry  # not published at this version, e.g. a conference that hasn't happened yet
            continue

        expected = entry and entry["sha256"]
        if dest.exists() and (not expected or sha256(dest) == expected):
            status = "ok"
        else:
            if dest.exists():
                print(f"  hash mismatch, re-downloading {rel}")
            if not download(url, dest):
                print(f"  missing  {rel} (not published at this version)")
                new_lock[rel] = {"url": url, "missing": True}
                continue
            status = "fetched"

        digest = sha256(dest)
        if expected and digest != expected:
            problems.append(f"{rel}: download does not match the locked SHA-256 (upstream changed?)")
            continue
        new_lock[rel] = {"url": url, "sha256": digest, "bytes": dest.stat().st_size}
        print(f"  {status:<8} {rel} ({dest.stat().st_size / 1e6:.1f} MB)")

    if problems:
        print("\nERROR:\n  " + "\n  ".join(problems), file=sys.stderr)
        return 1
    if new_lock != lock:
        LOCK.write_text(json.dumps(new_lock, indent=1, sort_keys=True) + "\n")
        print(f"\nwrote {LOCK.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
