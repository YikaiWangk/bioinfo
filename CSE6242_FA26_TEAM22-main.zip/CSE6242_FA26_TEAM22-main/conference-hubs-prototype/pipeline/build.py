"""Turn the raw downloads into the compact JSON the web app loads.

Steps
1. Read every accepted paper and dedupe to one row per (venue, year, author).
2. Geocode each author's affiliation:
   email domain -> ROR org, else affiliation name -> ROR org,
   else the country's busiest geocoded cell (country-level fallback).
3. Aggregate authors to a 0.5 degree grid per (venue, year, country).
4. Emit candidate hub airports and the passport -> destination visa matrix.
"""
import csv
import json
import re
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
OUT = ROOT / "web" / "data"

VENUE_NAMES = {"nips": "NeurIPS", "icml": "ICML", "iclr": "ICLR"}
GRID = 0.5
MIN_DESTINATIONS = 40  # candidate hubs need this many distinct nonstop destinations (OpenFlights)
GENERIC_SLD = {"edu", "ac", "com", "co", "org", "net", "gov", "res", "or", "ne", "go"}

# Airports for real past venues; always kept as candidates even if not "large".
PRESET_IATA = {
    "YVR", "MSY", "SAN", "MEX", "LAX", "BWI", "HNL", "VIE", "KGL", "SIN", "ADD", "CPH", "RIO", "GIG", "YUL", "SEA",
}


def write_json(path, obj):
    with open(path, "w") as f:
        json.dump(obj, f, separators=(",", ":"))


def split(s):
    return [x.strip() for x in (s or "").split(";")]


# ---------------------------------------------------------------- ROR index
def load_ror():
    with zipfile.ZipFile(RAW / "ror-data.zip") as z:
        name = max((i for i in z.infolist() if i.filename.endswith(".json")), key=lambda i: i.file_size).filename
        records = json.load(z.open(name))
    by_domain, by_name, country_names = {}, {}, {}
    for r in records:
        if r.get("status") != "active" or not r.get("locations"):
            continue
        g = r["locations"][0]["geonames_details"]
        if g.get("lat") is None:
            continue
        org = (g["lat"], g["lng"], g["country_code"])
        country_names[g["country_name"].lower()] = g["country_code"]
        doms = set(r.get("domains") or [])
        for link in r.get("links") or []:
            host = re.sub(r"^https?://", "", link.get("value", "")).split("/")[0].lower()
            doms.add(host.removeprefix("www."))
        for d in doms:
            if d:
                by_domain.setdefault(d, org)
        for n in r.get("names") or []:
            by_name.setdefault(n["value"].strip().lower(), org)
    return by_domain, by_name, country_names


def lookup_domain(domain, by_domain):
    labels = domain.lower().strip().split(".")
    for i in range(len(labels) - 1):
        cand = labels[i:]
        if len(cand) == 2 and cand[0] in GENERIC_SLD:
            break
        hit = by_domain.get(".".join(cand))
        if hit:
            return hit
    return None


# ---------------------------------------------------------------- papers
def is_accepted(status):
    s = (status or "").lower()
    return not any(w in s for w in ("reject", "withdraw", "desk"))


MIN_COVERAGE = 0.40  # skip venue-years whose source list mostly lacks affiliations


def load_authors(by_domain, by_name, country_names):
    """Yield (venue, year, geo_or_None, country_or_None) for venue-years with usable affiliations."""
    seen = set()
    coverage = []
    for path in sorted((RAW / "papers").glob("*.json")):
        venue, year = path.stem[:-4], int(path.stem[-4:])
        with open(path) as f:
            papers = json.load(f)
        n_papers = n_auth = n_geo = 0
        rows = []
        for p in papers:
            if not is_accepted(p.get("status")):
                continue
            n_papers += 1
            if p.get("author"):
                names = split(p["author"])
            else:
                names = [a.strip() for a in (p.get("author_site") or "").split(",")]
            ids = split(p.get("authorids"))
            affs, doms = split(p.get("aff")), split(p.get("aff_domain"))
            cidx, cuniq = split(p.get("aff_country_unique_index")), split(p.get("aff_country_unique"))
            uidx = split(p.get("aff_unique_index"))
            unorm, uurl = split(p.get("aff_unique_norm")), split(p.get("aff_unique_url"))
            for i, name in enumerate(names):
                if not name:
                    continue
                key = (venue, year, ids[i] if i < len(ids) and ids[i] else name.lower())
                if key in seen:
                    continue
                seen.add(key)
                n_auth += 1
                geo = None
                if i < len(doms) and doms[i]:
                    geo = lookup_domain(doms[i], by_domain)
                if not geo and i < len(affs) and affs[i]:
                    geo = by_name.get(affs[i].split("+")[0].strip().lower())
                # Paper Copilot's normalized affiliation (index may list several as "0+1"; take the first).
                u = uidx[i].split("+")[0] if i < len(uidx) else ""
                if not geo and u.isdigit() and int(u) < len(unorm):
                    j = int(u)
                    url = uurl[j] if j < len(uurl) else ""
                    host = re.sub(r"^https?://", "", url).split("/")[0].removeprefix("www.")
                    geo = (host and lookup_domain(host, by_domain)) or by_name.get(unorm[j].lower())
                country = geo[2] if geo else None
                if not country and i < len(cidx) and cidx[i].isdigit() and int(cidx[i]) < len(cuniq):
                    country = country_names.get(cuniq[int(cidx[i])].lower())
                if geo:
                    n_geo += 1
                rows.append((venue, year, geo, country))
        kept = n_auth and n_geo / n_auth >= MIN_COVERAGE
        coverage.append((path.stem, n_papers, n_auth, n_geo, kept))
        if kept:
            yield from rows
    print(f"{'file':<10}{'papers':>8}{'authors':>9}{'geo%':>7}")
    for stem, p, a, g, kept in coverage:
        print(f"{stem:<10}{p:>8}{a:>9}{(100 * g / a if a else 0):>6.0f}%{'' if kept else '  (skipped)'}")


# ---------------------------------------------------------------- main
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    by_domain, by_name, country_names = load_ror()
    print(f"ROR: {len(by_domain)} domains, {len(by_name)} names")

    cells = Counter()        # (venue, year, lat, lon, country) -> authors
    pending = Counter()      # (venue, year, country) -> authors without coordinates
    dropped = 0
    for venue, year, geo, country in load_authors(by_domain, by_name, country_names):
        if geo:
            lat, lon = round(geo[0] / GRID) * GRID, round(geo[1] / GRID) * GRID
            cells[(venue, year, lat, lon, geo[2])] += 1
        elif country:
            pending[(venue, year, country)] += 1
        else:
            dropped += 1

    # Country-level fallback: put unmatched authors at that country's busiest cell.
    busiest = defaultdict(Counter)
    for (_, _, lat, lon, c), n in cells.items():
        busiest[c][(lat, lon)] += n
    unplaced = 0
    for (v, y, c), n in pending.items():
        if busiest[c]:
            lat, lon = busiest[c].most_common(1)[0][0]
            cells[(v, y, lat, lon, c)] += n
        else:
            unplaced += n

    total = sum(cells.values())
    venues = sorted({k[0] for k in cells})
    countries = sorted({k[4] for k in cells})
    vi = {v: i for i, v in enumerate(venues)}
    ci = {c: i for i, c in enumerate(countries)}
    rows = [[lat, lon, ci[c], vi[v], y, n] for (v, y, lat, lon, c), n in sorted(cells.items())]
    by_country = Counter()
    for (*_, c), n in cells.items():
        by_country[c] += n
    years = sorted({k[1] for k in cells})
    print(f"\nauthor-venue-years placed: {total}  country-fallback: {sum(pending.values()) - unplaced}  "
          f"dropped (no country): {dropped + unplaced}  grid rows: {len(rows)}")
    print("top countries:", ", ".join(f"{c} {n}" for c, n in by_country.most_common(10)))

    write_json(OUT / "origins.json", {
        "venues": [VENUE_NAMES.get(v, v) for v in venues],
        "years": years,
        "countries": countries,
        "rows": rows,
        "stats": {"placed": total, "dropped": dropped + unplaced},
    })

    # Candidate hubs: well-connected passenger airports (by distinct nonstop destinations), one per city.
    dests_by_airport = defaultdict(set)
    with open(RAW / "routes.dat", newline="", encoding="utf-8") as f:
        for r in csv.reader(f):
            dests_by_airport[r[2]].add(r[4])
            dests_by_airport[r[4]].add(r[2])
    cands, seen_city = [], set()
    with open(RAW / "airports.csv", newline="", encoding="utf-8") as f:
        for a in csv.DictReader(f):
            iata = a["iata_code"]
            if not iata or a["scheduled_service"] != "yes":
                continue
            if len(dests_by_airport[iata]) < MIN_DESTINATIONS and iata not in PRESET_IATA:
                continue
            city = (a["municipality"] or a["name"]).strip()
            if (city, a["iso_country"]) in seen_city and iata not in PRESET_IATA:
                continue
            seen_city.add((city, a["iso_country"]))
            cands.append({"iata": iata, "city": city, "country": a["iso_country"],
                          "lat": round(float(a["latitude_deg"]), 3), "lon": round(float(a["longitude_deg"]), 3)})
    write_json(OUT / "candidates.json", cands)
    print(f"candidate airports: {len(cands)}")

    # Visa categories: 0 none needed, 1 eTA / e-visa / on arrival, 2 visa required, 3 no admission.
    def category(req):
        r = req.strip().lower()
        if r.lstrip("-").isdigit() or r == "visa free":
            return 0
        if r in ("eta", "e-visa", "visa on arrival"):
            return 1
        if r == "visa required":
            return 2
        return 3  # "no admission", "covid ban", unknown
    dests = sorted({c["country"] for c in cands})
    di = {d: i for i, d in enumerate(dests)}
    matrix = {c: [2] * len(dests) for c in countries}
    for c in countries:
        if c in di:
            matrix[c][di[c]] = 0
    with open(RAW / "passport-index-tidy-iso2.csv", newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r["Passport"] in matrix and r["Destination"] in di:
                matrix[r["Passport"]][di[r["Destination"]]] = category(r["Requirement"])
    write_json(OUT / "visa.json", {"dests": dests, "matrix": {c: "".join(map(str, m)) for c, m in matrix.items()}})
    print(f"visa matrix: {len(countries)} passports x {len(dests)} destinations")


if __name__ == "__main__":
    main()
