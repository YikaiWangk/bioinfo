// Real host cities, used as presets and baselines ("what if this edition had been held elsewhere?").
const PRESETS = [
  { venue: "NeurIPS", year: 2019, iatas: ["YVR"], label: "Vancouver" },
  { venue: "NeurIPS", year: 2022, iatas: ["MSY"], label: "New Orleans" },
  { venue: "NeurIPS", year: 2023, iatas: ["MSY"], label: "New Orleans" },
  { venue: "NeurIPS", year: 2024, iatas: ["YVR"], label: "Vancouver" },
  { venue: "NeurIPS", year: 2025, iatas: ["SAN", "MEX"], label: "San Diego + Mexico City" },
  { venue: "ICML", year: 2019, iatas: ["LAX"], label: "Long Beach" },
  { venue: "ICML", year: 2022, iatas: ["BWI"], label: "Baltimore" },
  { venue: "ICML", year: 2023, iatas: ["HNL"], label: "Honolulu" },
  { venue: "ICML", year: 2024, iatas: ["VIE"], label: "Vienna" },
  { venue: "ICML", year: 2025, iatas: ["YVR"], label: "Vancouver" },
  { venue: "ICLR", year: 2023, iatas: ["KGL"], label: "Kigali" },
  { venue: "ICLR", year: 2024, iatas: ["VIE"], label: "Vienna" },
];
const PARETO_LAMBDAS = [0, 0.25, 0.5, 1, 1.5, 2, 3, 5];
const VISA_LABEL = ["no visa", "eTA / e-visa / on arrival", "visa required", "no admission"];
const hubColor = (h) => `var(--series-${h + 1})`;

const state = {
  venues: new Set(), yearFrom: 2023, yearTo: 2025, k: 2, lambda: 1,
  hubs: [], baseline: null, result: null, pareto: null, points: [], tables: null,
};
let data, cands, byIata, worker, reqId = 0;

const fmtT = (t) => (t >= 1e3 ? `${d3.format(",.1f")(t / 1e3)} kt` : `${d3.format(",.0f")(t)} t`);
const fmtPct = d3.format(".1%");
const fmtInt = d3.format(",");

// ------------------------------------------------------------------ data
async function load() {
  const [origins, candidates, visa, world] = await Promise.all([
    d3.json("data/origins.json"), d3.json("data/candidates.json"), d3.json("data/visa.json"),
    d3.json("vendor/countries-110m.json"),
  ]);
  data = { origins, visa, land: topojson.feature(world, world.objects.land) };
  cands = candidates;
  byIata = new Map(cands.map((c, i) => [c.iata, i]));
  origins.venues.forEach((v) => state.venues.add(v));
  worker = new Worker("solver.js");
  worker.onmessage = onWorker;
}

function aggregatePoints() {
  const { rows, venues, countries } = data.origins;
  const cells = new Map();
  for (const [lat, lon, ci, vi, year, n] of rows) {
    if (!state.venues.has(venues[vi]) || year < state.yearFrom || year > state.yearTo) continue;
    const key = `${lat},${lon},${ci}`;
    const c = cells.get(key);
    if (c) c.w += n;
    else cells.set(key, { lat, lon, country: countries[ci], w: n });
  }
  return [...cells.values()].sort((a, b) => b.w - a.w);
}

// Rebuild cost tables after a filter change, then re-optimize and refresh the trade-off curve.
function refreshData({ optimize = true } = {}) {
  state.points = aggregatePoints();
  state.pareto = null;
  if (!state.points.length) {
    state.tables = null;
    state.result = null;
    setStatus("No papers with affiliations for this selection.");
    render();
    return;
  }
  state.tables = buildTables(state.points, cands, data.visa);
  worker.postMessage({ type: "tables", points: state.points, cands, visa: data.visa });
  if (optimize) runOptimize();
  else rescore();
  runPareto();
}

function rescore() {
  state.result = state.tables && state.hubs.length ? evaluate(state.tables, state.hubs, state.lambda) : null;
  render();
}

// ------------------------------------------------------------------ worker
function runOptimize() {
  setBusy(true, "Optimizing…");
  worker.postMessage({ type: "optimize", id: ++reqId, k: state.k, lambda: state.lambda });
}
function runPareto() {
  worker.postMessage({ type: "pareto", id: reqId, k: state.k, lambdas: PARETO_LAMBDAS });
}
function onWorker({ data: msg }) {
  if (msg.type === "optimized" && msg.id === reqId) {
    state.hubs = msg.hubs;
    setBusy(false, "");
    rescore();
  } else if (msg.type === "pareto" && msg.id === reqId) {
    state.pareto = msg.points;
    renderPareto();
  } else if (msg.type === "selftest") {
    console.table(msg.res.map((r) => ({
      lambda: r.lambda, optimized: cands[r.optimized].city, brute_force: cands[r.brute].city, match: r.optimized === r.brute,
    })));
  }
}
function setBusy(busy, text) {
  d3.select("#optimize").property("disabled", busy);
  setStatus(text);
}
function setStatus(text) { d3.select("#status").text(text); }

// ------------------------------------------------------------------ controls
function initControls() {
  const venues = data.origins.venues;
  const vf = d3.select("#venues").selectAll("label").data(venues).join("label");
  vf.append("input").attr("type", "checkbox").property("checked", true).on("change", function (e, v) {
    this.checked ? state.venues.add(v) : state.venues.delete(v);
    clearPreset();
    refreshData();
  });
  vf.append("span").text((v) => v);

  const years = data.origins.years;
  for (const id of ["yearFrom", "yearTo"]) {
    d3.select(`#${id}`).selectAll("option").data(years).join("option").attr("value", (y) => y).text((y) => y);
    d3.select(`#${id}`).property("value", state[id]).on("change", function () {
      state[id] = +this.value;
      if (state.yearFrom > state.yearTo) [state.yearFrom, state.yearTo] = [state.yearTo, state.yearFrom];
      syncControls();
      clearPreset();
      refreshData();
    });
  }

  const have = new Set(data.origins.rows.map((r) => `${venues[r[3]]}${r[4]}`));
  const presets = PRESETS.filter((p) => have.has(`${p.venue}${p.year}`) && p.iatas.every((c) => byIata.has(c)));
  d3.select("#preset").selectAll("option.p").data(presets).join("option").attr("class", "p")
    .attr("value", (_, i) => i).text((p) => `${p.venue} ${p.year} · ${p.label}`);
  d3.select("#preset").on("change", function () {
    if (this.value === "") return;
    const p = presets[+this.value];
    state.venues = new Set([p.venue]);
    state.yearFrom = state.yearTo = p.year;
    state.k = p.iatas.length;
    state.hubs = p.iatas.map((c) => byIata.get(c));
    reqId++; // discard any in-flight optimize result
    syncControls();
    refreshData({ optimize: false });
    state.baseline = { ...summary(state.result), label: `${p.venue} ${p.year} actual (${p.label})` };
    render();
  });

  d3.select("#k").on("input", function () {
    state.k = +this.value;
    d3.select("#kOut").text(state.k);
  }).on("change", () => { clearPreset(); runOptimize(); runPareto(); });

  d3.select("#lambda").on("input", function () {
    state.lambda = +this.value;
    d3.select("#lambdaOut").text(state.lambda.toFixed(2));
    rescore();
    renderPareto();
  });

  d3.select("#optimize").on("click", () => { clearPreset(); runOptimize(); });
  d3.select("#baselineBtn").on("click", () => {
    if (!state.result) return;
    state.baseline = { ...summary(state.result), label: "your saved baseline" };
    render();
  });
}

function syncControls() {
  d3.selectAll("#venues input").property("checked", (v) => state.venues.has(v));
  d3.select("#yearFrom").property("value", state.yearFrom);
  d3.select("#yearTo").property("value", state.yearTo);
  d3.select("#k").property("value", state.k);
  d3.select("#kOut").text(state.k);
}
function clearPreset() { d3.select("#preset").property("value", ""); }

function summary(r) {
  return r ? { co2: r.co2, per: r.co2 / r.total, visa: r.visaReq / r.total } : null;
}

// ------------------------------------------------------------------ globe
const svg = d3.select("#globe");
const projection = d3.geoOrthographic().clipAngle(90).rotate([40, -30]);
const path = d3.geoPath(projection);
const gSphere = svg.append("path").attr("class", "ocean");
const gGrat = svg.append("path").attr("class", "graticule");
const gLand = svg.append("path").attr("class", "land");
const gCands = svg.append("g");
const gArcs = svg.append("g");
const gOrigins = svg.append("g");
const gHubs = svg.append("g");
const snapRing = svg.append("circle").attr("class", "snap").attr("r", 13).attr("display", "none");
const tooltip = d3.select("#tooltip");

function resize() {
  const { width, height } = svg.node().getBoundingClientRect();
  projection.fitExtent([[16, 28], [width - 16, height - 16]], { type: "Sphere" });
  render();
}

const visible = (lon, lat) => {
  const r = projection.rotate();
  return d3.geoDistance([lon, lat], [-r[0], -r[1]]) < Math.PI / 2 - 0.01;
};

function render() {
  if (!data) return;
  gSphere.attr("d", path({ type: "Sphere" }));
  gGrat.attr("d", path(d3.geoGraticule10()));
  gLand.attr("d", path(data.land));

  gCands.selectAll("circle").data(cands.filter((c) => visible(c.lon, c.lat)), (c) => c.iata)
    .join("circle").attr("class", "candidate").attr("r", 1.2)
    .attr("cx", (c) => projection([c.lon, c.lat])[0]).attr("cy", (c) => projection([c.lon, c.lat])[1]);

  const r = state.result;
  const pts = state.points;
  const maxW = d3.max(pts, (p) => p.w) || 1;
  const radius = d3.scaleSqrt().domain([0, maxW]).range([0, 22]);

  // Great-circle arcs from the 30 largest origins of each hub.
  const arcs = [];
  if (r) {
    state.hubs.forEach((hj, h) => {
      const hub = cands[hj];
      pts.map((p, i) => ({ p, i })).filter(({ i }) => r.assign[i] === h).slice(0, 30)
        .forEach(({ p }) => arcs.push({ h, line: { type: "LineString", coordinates: [[p.lon, p.lat], [hub.lon, hub.lat]] } }));
    });
  }
  gArcs.selectAll("path").data(arcs).join("path").attr("class", "arc")
    .attr("d", (a) => path(a.line)).style("stroke", (a) => hubColor(a.h));

  const shown = pts.map((p, i) => ({ p, i })).filter(({ p }) => visible(p.lon, p.lat));
  gOrigins.selectAll("circle").data(shown, (d) => `${d.p.lat},${d.p.lon},${d.p.country}`)
    .join("circle").attr("class", "origin")
    .attr("cx", (d) => projection([d.p.lon, d.p.lat])[0]).attr("cy", (d) => projection([d.p.lon, d.p.lat])[1])
    .attr("r", (d) => Math.max(1.5, radius(d.p.w)))
    .style("fill", (d) => (r ? hubColor(r.assign[d.i]) : "var(--muted)"))
    .on("pointermove", (e, d) => showOriginTip(e, d))
    .on("pointerleave", hideTip);

  const hubs = state.hubs.map((j, h) => ({ h, c: cands[j] })).filter(({ c }) => visible(c.lon, c.lat));
  const hg = gHubs.selectAll("g").data(hubs, (d) => d.h).join((enter) => {
    const g = enter.append("g");
    g.append("circle").attr("class", "hub").attr("r", 9);
    g.append("text").attr("class", "hub-label").attr("x", 13).attr("dy", "0.35em");
    return g;
  });
  hg.attr("transform", (d) => `translate(${projection([d.c.lon, d.c.lat])})`);
  hg.select("circle").style("fill", (d) => hubColor(d.h)).call(hubDrag);
  hg.select("text").text((d) => `${d.c.city} (${d.c.iata})`);

  renderLegend();
  renderPanel();
}

function showOriginTip(e, { p, i }) {
  const r = state.result;
  let body = `<b>≈${fmtInt(p.w)} author-papers</b> <span class="t2">· ${p.country}</span>`;
  if (r) {
    const hub = cands[state.hubs[r.assign[i]]];
    const idx = i * state.tables.m + state.hubs[r.assign[i]];
    body += `<br>Goes to <b>${hub.city}</b> · ${state.tables.co2[idx].toFixed(2)} t CO₂e round trip each` +
      `<br><span class="t2">${VISA_LABEL[state.tables.cat[idx]]}</span>`;
  }
  showTip(e, body);
}
function showTip(e, html) {
  tooltip.html(html).attr("hidden", null)
    .style("left", `${Math.min(e.clientX + 14, innerWidth - 270)}px`).style("top", `${e.clientY + 14}px`);
}
function hideTip() { tooltip.attr("hidden", true); }

// Rotate the globe by dragging the background.
svg.call(d3.drag().filter((e) => !e.target.classList.contains("hub")).on("drag", (e) => {
  const [l, p] = projection.rotate();
  const k = 75 / projection.scale();
  projection.rotate([l + e.dx * k, Math.max(-85, Math.min(85, p - e.dy * k))]);
  hideTip();
  render();
}));

// Drag a hub; it snaps to the nearest candidate airport and the scores update live.
function nearestCandidate(lon, lat) {
  let best = 0, bd = Infinity;
  cands.forEach((c, j) => {
    const d = haversineKm(lat, lon, c.lat, c.lon);
    if (d < bd) { bd = d; best = j; }
  });
  return best;
}
const hubDrag = d3.drag()
  .on("start", function () { d3.select(this).style("cursor", "grabbing"); clearPreset(); })
  .on("drag", function (e, d) {
    const ll = projection.invert(d3.pointer(e, svg.node()));
    if (!ll) return;
    const j = nearestCandidate(ll[0], ll[1]);
    if (state.hubs.includes(j) && state.hubs[d.h] !== j) return;
    state.hubs[d.h] = j;
    snapRing.attr("display", null).attr("transform", `translate(${projection([cands[j].lon, cands[j].lat])})`);
    rescore();
    renderPareto();
  })
  .on("end", function () { d3.select(this).style("cursor", null); snapRing.attr("display", "none"); });

function renderLegend() {
  const items = state.hubs.map((j, h) => `<span><i style="background:${hubColor(h)}"></i>${cands[j].city}</span>`);
  items.push(`<span class="muted">circle area = authors · arcs = 30 largest origins per hub</span>`);
  d3.select("#legend").html(items.join(""));
}

// ------------------------------------------------------------------ panel
function renderPanel() {
  const r = state.result;
  const s = summary(r), b = state.baseline;
  d3.select("#mCo2").text(s ? fmtT(s.co2) : "–");
  d3.select("#mPer").text(s ? `${s.per.toFixed(2)} t` : "–");
  d3.select("#mVisa").text(s ? fmtPct(s.visa) : "–");
  const delta = (id, cur, base, fmt) => {
    const el = d3.select(id);
    if (!s || !b) return el.text("").attr("class", "tile-delta");
    const d = cur - base;
    if (Math.abs(d) < 1e-6 * Math.max(1, Math.abs(base))) return el.text("same as baseline").attr("class", "tile-delta");
    el.attr("class", `tile-delta ${d < -1e-9 ? "good" : d > 1e-9 ? "bad" : ""}`)
      .text(`${d <= 0 ? "▼" : "▲"} ${fmt(Math.abs(d))} vs baseline`).attr("title", `Baseline: ${b.label}`);
  };
  delta("#dCo2", s?.co2, b?.co2, (d) => `${d3.format(".0%")(d / b.co2)}`);
  delta("#dPer", s?.per, b?.per, (d) => `${d.toFixed(2)} t`);
  delta("#dVisa", s?.visa, b?.visa, (d) => `${(d * 100).toFixed(1)} pts`);

  const rows = r ? state.hubs.map((j, h) => ({ h, c: cands[j], l: r.load[h] })) : [];
  const hr = d3.select("#hubs").selectAll(".hub-row").data(rows).join((enter) => {
    const row = enter.append("div").attr("class", "hub-row");
    row.append("div").attr("class", "name").call((n) => { n.append("i"); n.append("span"); });
    row.append("div").attr("class", "val");
    row.append("div").attr("class", "bar").append("div");
    row.append("div").attr("class", "sub2");
    return row;
  });
  hr.select(".name i").style("background", (d) => hubColor(d.h));
  hr.select(".name span").text((d) => `${d.c.city} (${d.c.iata}, ${d.c.country})`);
  hr.select(".val").text((d) => `${fmtPct(d.l.w / r.total)} of authors`);
  hr.select(".bar div").style("width", (d) => `${(100 * d.l.w) / r.total}%`).style("background", (d) => hubColor(d.h));
  hr.select(".sub2").text((d) => d.l.w
    ? `${fmtPct(d.l.visa / d.l.w)} need a visa · ${(d.l.co2 / d.l.w).toFixed(2)} t CO₂e each`
    : "no attendees assigned");

  const total = d3.sum(state.points, (p) => p.w);
  d3.select("#foot").html(
    `${fmtInt(total)} author-papers (deduplicated per venue-year) from ${fmtInt(state.points.length)} locations · ` +
    `${fmtInt(cands.length)} candidate airports.` + (b ? ` Baseline: ${b.label}.` : "") +
    `<br>Data: Paper Copilot paper lists, ROR, OurAirports, Passport Index. Emission factors: UK DESNZ 2023 (incl. RF).`);
}

function renderPareto() {
  const el = d3.select("#pareto");
  d3.select("#paretoK").text(`(k = ${state.k})`);
  const { width } = el.node().getBoundingClientRect();
  const height = 200, m = { t: 10, r: 12, b: 34, l: 48 };
  el.selectAll("*").remove();
  const pts = state.pareto;
  if (!pts) {
    el.append("text").attr("x", width / 2).attr("y", height / 2).attr("text-anchor", "middle")
      .attr("class", "muted").style("fill", "var(--muted)").style("font-size", "12px").text("Computing trade-off curve…");
    return;
  }
  // Several λ often return the same hub set; merge them into one dot.
  const sols = [];
  for (const p of pts) {
    const key = p.hubs.slice().sort((a, b) => a - b).join();
    const s = sols.find((q) => q.key === key);
    if (s) s.lambdas.push(p.lambda);
    else sols.push({ ...p, key, lambdas: [p.lambda] });
  }
  const cur = summary(state.result);
  const all = [...sols.map((p) => ({ x: p.visaShare, y: p.co2 / 1e3 })), ...(cur ? [{ x: cur.visa, y: cur.co2 / 1e3 }] : [])];

  // Honest scales: the share axis starts at 0 and spans at least 5 points; the emissions axis spans
  // at least 10% of its top value, so differences of a few tonnes aren't stretched to fill the chart.
  const x = d3.scaleLinear().domain([0, Math.max(0.05, 1.1 * d3.max(all, (d) => d.x))]).nice().range([m.l, width - m.r]);
  const [y0, y1] = d3.extent(all, (d) => d.y);
  const pad = Math.max(0, (0.1 * y1 - (y1 - y0)) / 2);
  const y = d3.scaleLinear().domain([Math.max(0, y0 - pad), y1 + pad]).nice().range([height - m.b, m.t]);
  el.append("g").attr("class", "axis").attr("transform", `translate(0,${height - m.b})`)
    .call(d3.axisBottom(x).ticks(4, "~%").tickSizeOuter(0));
  el.append("g").attr("class", "axis").attr("transform", `translate(${m.l},0)`)
    .call(d3.axisLeft(y).ticks(4, ",~f").tickSizeOuter(0));
  el.append("text").attr("x", m.l + 4).attr("y", m.t + 4).attr("dy", "0.7em")
    .style("fill", "var(--muted)").style("font-size", "11px").text("kt CO₂e");
  el.append("text").attr("x", width - m.r).attr("y", height - 4).attr("text-anchor", "end")
    .style("fill", "var(--muted)").style("font-size", "11px").text("share of attendees needing a visa →");
  el.append("path").attr("class", "pareto-line")
    .attr("d", d3.line().x((p) => x(p.visaShare)).y((p) => y(p.co2 / 1e3))(sols));
  el.append("g").selectAll("circle").data(sols).join("circle").attr("class", "pareto-dot").attr("r", 5)
    .attr("cx", (p) => x(p.visaShare)).attr("cy", (p) => y(p.co2 / 1e3))
    .on("pointermove", (e, p) => showTip(e,
      `<b>λ = ${p.lambdas.join(", ")}</b><br>${p.hubs.map((j) => cands[j].city).join(" · ")}` +
      `<br>${fmtT(p.co2)} · ${fmtPct(p.visaShare)} need a visa` +
      `<br><span class="t2">${fmtPct(p.evisaShare)} need an eTA / e-visa (penalized at 0.25 λ)</span>`))
    .on("pointerleave", hideTip)
    .on("click", (e, p) => {
      state.lambda = p.lambda;
      state.hubs = p.hubs.slice();
      d3.select("#lambda").property("value", p.lambda);
      d3.select("#lambdaOut").text(p.lambda.toFixed(2));
      clearPreset();
      rescore();
      renderPareto();
    });

  const flat = sols.length === 1 ||
    ((d3.max(sols, (p) => p.co2) - d3.min(sols, (p) => p.co2)) / d3.max(sols, (p) => p.co2) < 0.02 &&
     d3.max(sols, (p) => p.visaShare) - d3.min(sols, (p) => p.visaShare) < 0.01);
  d3.select("#paretoNote").text(flat
    ? `Little trade-off at k = ${state.k}: every λ gives nearly the same emissions and visa share.`
    : "Each dot is an optimal hub set (labelled by the λ values that produce it). Click a dot to load it.");
  if (cur) {
    el.append("circle").attr("class", "pareto-current").attr("r", 9).attr("cx", x(cur.visa)).attr("cy", y(cur.co2 / 1e3))
      .append("title").text("current hubs");
  }
}

// ------------------------------------------------------------------ boot
load().then(() => {
  initControls();
  syncControls();
  resize();
  refreshData();
  if (new URLSearchParams(location.search).has("selftest")) {
    worker.postMessage({ type: "selftest", lambdas: [0, 1, 3] });
  }
});
addEventListener("resize", () => { resize(); renderPareto(); });
