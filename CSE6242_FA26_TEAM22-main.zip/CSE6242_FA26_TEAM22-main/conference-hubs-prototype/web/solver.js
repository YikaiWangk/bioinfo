// Cost model + weighted p-median optimizer.
// Loaded both as a page script (for live re-scoring while dragging) and as a Web Worker (for optimizing).

// Flight emissions, kg CO2e per passenger-km including radiative forcing
// (UK DEFRA/DESNZ 2023 "average passenger" factors). Under 300 km we assume rail/coach.
const GROUND_KM = 300;
const EMISSION_BANDS = [
  [GROUND_KM, 0.035], // rail / coach
  [785, 0.246],       // domestic-length flight
  [3700, 0.186],      // short-haul
  [Infinity, 0.261],  // long-haul
];
const ROUTE_UPLIFT = 1.08; // actual routes are longer than great-circle

// Visa categories from build.py: 0 none, 1 eTA / e-visa / on arrival, 2 visa required, 3 no admission.
// Penalty is a multiple of lambda (tCO2e-equivalent per affected attendee).
const VISA_WEIGHT = [0, 0.25, 1, 10];

function haversineKm(lat1, lon1, lat2, lon2) {
  const r = Math.PI / 180;
  const a = Math.sin(((lat2 - lat1) * r) / 2) ** 2 +
    Math.cos(lat1 * r) * Math.cos(lat2 * r) * Math.sin(((lon2 - lon1) * r) / 2) ** 2;
  return 12742 * Math.asin(Math.sqrt(a));
}

// Round-trip tonnes CO2e for one attendee.
function tripTonnes(km) {
  const d = km * ROUTE_UPLIFT;
  const factor = EMISSION_BANDS.find(([max]) => d < max)[1];
  return (2 * d * factor) / 1000;
}

// Build the per-(point, candidate) CO2 and visa-category tables once per filter change.
// points: {lat, lon, country, w}[], cands: {lat, lon, country}[], visa: {dests, matrix}
function buildTables(points, cands, visa) {
  const n = points.length, m = cands.length;
  const co2 = new Float32Array(n * m);
  const cat = new Uint8Array(n * m);
  const destIdx = new Map(visa.dests.map((d, i) => [d, i]));
  for (let i = 0; i < n; i++) {
    const p = points[i];
    const row = visa.matrix[p.country];
    for (let j = 0; j < m; j++) {
      const c = cands[j];
      co2[i * m + j] = tripTonnes(haversineKm(p.lat, p.lon, c.lat, c.lon));
      let k = 2; // unknown passport/destination: assume a visa is required
      if (p.country === c.country) k = 0;
      else if (row) k = +row[destIdx.get(c.country)];
      cat[i * m + j] = k;
    }
  }
  return { n, m, co2, cat, w: Float64Array.from(points, (p) => p.w) };
}

function makeCost(t, lambda) {
  const pen = VISA_WEIGHT.map((v) => v * lambda);
  return (i, j) => t.co2[i * t.m + j] + pen[t.cat[i * t.m + j]];
}

// Assign each point to its cheapest hub and summarize.
function evaluate(t, hubs, lambda) {
  const cost = makeCost(t, lambda);
  const assign = new Int32Array(t.n);
  const load = hubs.map(() => ({ w: 0, co2: 0, visa: 0 }));
  let objective = 0, co2 = 0, visaReq = 0, evisa = 0, total = 0;
  for (let i = 0; i < t.n; i++) {
    let best = Infinity, bh = 0;
    for (let h = 0; h < hubs.length; h++) {
      const c = cost(i, hubs[h]);
      if (c < best) { best = c; bh = h; }
    }
    const idx = i * t.m + hubs[bh], w = t.w[i], k = t.cat[idx];
    assign[i] = bh;
    objective += w * best;
    co2 += w * t.co2[idx];
    total += w;
    if (k >= 2) visaReq += w;
    else if (k === 1) evisa += w;
    load[bh].w += w;
    load[bh].co2 += w * t.co2[idx];
    if (k >= 2) load[bh].visa += w;
  }
  return { hubs: hubs.slice(), assign, load, objective, co2, visaReq, evisa, total };
}

// Weighted p-median: greedy add, then vertex-substitution (Teitz-Bart) swaps to a local optimum.
function optimize(t, k, lambda) {
  const cost = makeCost(t, lambda);
  const { n, m, w } = t;
  const hubs = [];
  const best = new Float64Array(n).fill(Infinity);

  for (let step = 0; step < k; step++) {
    let bj = -1, bv = Infinity;
    for (let j = 0; j < m; j++) {
      if (hubs.includes(j)) continue;
      let v = 0;
      for (let i = 0; i < n; i++) v += w[i] * Math.min(best[i], cost(i, j));
      if (v < bv) { bv = v; bj = j; }
    }
    hubs.push(bj);
    for (let i = 0; i < n; i++) best[i] = Math.min(best[i], cost(i, bj));
  }

  const total = (hs) => {
    let v = 0;
    for (let i = 0; i < n; i++) {
      let b = Infinity;
      for (const h of hs) b = Math.min(b, cost(i, h));
      v += w[i] * b;
    }
    return v;
  };

  if (k > 1) {
    // first[i]/second[i]: cheapest and second-cheapest cost among current hubs, owner[i]: index of cheapest
    let current = total(hubs), improved = true, passes = 0;
    const first = new Float64Array(n), second = new Float64Array(n), owner = new Int32Array(n);
    while (improved && passes++ < 20) {
      improved = false;
      for (let i = 0; i < n; i++) {
        let a = Infinity, b = Infinity, o = 0;
        hubs.forEach((h, hi) => {
          const c = cost(i, h);
          if (c < a) { b = a; a = c; o = hi; } else if (c < b) b = c;
        });
        first[i] = a; second[i] = b; owner[i] = o;
      }
      let bestSwap = null, bestVal = current - 1e-9;
      for (let j = 0; j < m; j++) {
        if (hubs.includes(j)) continue;
        for (let hi = 0; hi < hubs.length; hi++) {
          let v = 0;
          for (let i = 0; i < n; i++) {
            const keep = owner[i] === hi ? second[i] : first[i];
            v += w[i] * Math.min(keep, cost(i, j));
          }
          if (v < bestVal) { bestVal = v; bestSwap = [hi, j]; }
        }
      }
      if (bestSwap) {
        hubs[bestSwap[0]] = bestSwap[1];
        current = bestVal;
        improved = true;
      }
    }
  }
  return hubs;
}

// Exhaustive single-hub search, used by ?selftest to check optimize(t, 1, lambda).
function bruteForce1(t, lambda) {
  const cost = makeCost(t, lambda);
  let bj = -1, bv = Infinity;
  for (let j = 0; j < t.m; j++) {
    let v = 0;
    for (let i = 0; i < t.n; i++) v += t.w[i] * cost(i, j);
    if (v < bv) { bv = v; bj = j; }
  }
  return bj;
}

// ---- Web Worker entry point --------------------------------------------------------------
if (typeof importScripts === "function") {
  let tables = null;
  self.onmessage = ({ data }) => {
    if (data.type === "tables") {
      tables = buildTables(data.points, data.cands, data.visa);
    } else if (data.type === "optimize") {
      const hubs = optimize(tables, data.k, data.lambda);
      self.postMessage({ type: "optimized", id: data.id, hubs });
    } else if (data.type === "pareto") {
      const out = data.lambdas.map((lambda) => {
        const hubs = optimize(tables, data.k, lambda);
        const r = evaluate(tables, hubs, lambda);
        return { lambda, hubs, co2: r.co2, visaShare: r.visaReq / r.total, evisaShare: r.evisa / r.total };
      });
      self.postMessage({ type: "pareto", id: data.id, points: out });
    } else if (data.type === "selftest") {
      const res = data.lambdas.map((lambda) => ({
        lambda, optimized: optimize(tables, 1, lambda)[0], brute: bruteForce1(tables, lambda),
      }));
      self.postMessage({ type: "selftest", res });
    }
  };
}
