import js from "@eslint/js";
import globals from "globals";

// web/*.js are classic <script>s sharing one global scope (no bundler):
// solver.js defines the cost model and optimizer, app.js calls them. solver.js also runs as a Web Worker.
const solverExports = ["buildTables", "evaluate", "optimize", "bruteForce1", "tripTonnes", "haversineKm"];

export default [
  { ignores: ["node_modules/", "web/vendor/", ".pixi/"] },
  js.configs.recommended,
  {
    files: ["web/**/*.js"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "script",
      globals: { ...globals.browser, d3: "readonly", topojson: "readonly" },
    },
  },
  {
    files: ["web/app.js"],
    languageOptions: {
      globals: Object.fromEntries(solverExports.map((name) => [name, "readonly"])),
    },
  },
  {
    files: ["web/solver.js"],
    languageOptions: { globals: { ...globals.worker } },
    // Top-level functions here are used by app.js, which ESLint can't see.
    rules: { "no-unused-vars": ["error", { vars: "local" }] },
  },
];
